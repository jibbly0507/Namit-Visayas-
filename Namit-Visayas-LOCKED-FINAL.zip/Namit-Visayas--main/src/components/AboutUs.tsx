import React from 'react';
import { FoodItem } from '../types';
import { Award } from 'lucide-react';

interface AboutUsProps {
  items: FoodItem[];
  manifestoTitle?: string;
  manifestoText?: string;
  onSelectFood: (item: FoodItem) => void;
}

export const AboutUs: React.FC<AboutUsProps> = ({ items, manifestoTitle = 'Group 4 · Tourism & Promotion Team', manifestoText = 'Eight student researchers collaborated on Namit 4 Visayas.', onSelectFood }) => (
  <section id="about" className="py-14 sm:py-20 border-b border-[#E8DDCF] bg-[#FAF6F0]">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="text-xs font-bold uppercase tracking-wider text-[#BF360C]">Meet the Proponents</div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1E1B18] font-['Outfit'] mt-1">Group 4 · Tourism & Promotion Team</h2>
        <p className="text-sm sm:text-base text-[#685F53] mt-2">Eight passionate student researchers collaborating on <em>"Namit 4 Visayas."</em> Each proponent conducted field and archival research to document and curate one signature delicacy representing the cultural soul of Western Visayas.</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {items.map((item, idx) => {
          const member = item.submitter;
          return <article key={member.id} className="bg-white rounded-2xl border border-[#E5DACD] p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between">
            <div>
              <div className="flex flex-col items-center text-center">
                <div className="relative mb-3.5"><div className="w-24 h-24 rounded-full p-1 bg-gradient-to-tr from-[#E65100] via-[#F57C00] to-[#0F4C3A] shadow-md"><img src={member.avatar} alt={`${member.name} formal picture`} className="w-full h-full rounded-full object-cover bg-[#F0E6D8]" /></div></div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-[#BF360C]">Member #{idx + 1} · {member.studentNumber}</div>
                <h3 className="text-base font-bold text-[#1E1B18] font-['Outfit'] mt-0.5">{member.name}</h3>
                <p className="text-xs text-[#706659] font-medium">{member.role}</p>
              </div>
              <div className="mt-4 pt-3 border-t border-[#F0E6D8] space-y-1.5 text-center"><span className="text-[10px] uppercase font-bold text-[#8A7968] tracking-wide">Assigned Food Entry:</span><button onClick={() => onSelectFood(item)} className="block w-full text-xs font-bold text-[#BF360C] hover:underline truncate">{item.title} ({item.province})</button></div>
            </div>
            <div className="mt-4 pt-3 border-t border-[#F0E6D8] flex justify-end"><button onClick={() => onSelectFood(item)} className="text-[11px] font-bold text-[#0F4C3A] hover:underline">View Food →</button></div>
          </article>;
        })}
      </div>
      <div className="mt-12 bg-white rounded-2xl border border-[#E5DACD] p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xs">
        <div className="space-y-2 max-w-2xl"><div className="flex items-center gap-2 text-xs font-bold text-[#0F4C3A] uppercase tracking-wide"><Award className="w-4 h-4" /><span>Attribution & Heritage Documentation</span></div><h4 className="text-lg font-bold text-[#1E1B18] font-['Outfit']">{manifestoTitle}</h4><p className="text-xs sm:text-sm text-[#5C544B] leading-relaxed">{manifestoText}</p></div>
        <div className="flex items-center gap-3 shrink-0"><div className="text-right"><div className="text-xs font-bold text-[#1E1B18]">Group 4 Roster</div><div className="text-[11px] text-[#7A6F62]">8 / 8 Fully Attributed</div></div><div className="w-10 h-10 rounded-full bg-[#EDF7F2] text-[#0F4C3A] flex items-center justify-center font-bold">✓</div></div>
      </div>
    </div>
  </section>
);
