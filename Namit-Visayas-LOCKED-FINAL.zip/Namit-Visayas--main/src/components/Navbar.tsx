import React, { useState } from 'react';
import { Logo } from './Logo';
import { Menu, X } from 'lucide-react';

interface NavbarProps {
  activeSection: string;
  onNavigate: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeSection, onNavigate }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navLinks = [
    { id: 'hero', label: 'Showcase' },
    { id: 'gallery', label: '8 Regional Dishes' },
    { id: 'about', label: 'Group 4 Team' },
  ];
  const handleLinkClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#FCFAF7]/95 backdrop-blur-md border-b border-[#EADFCF]/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-[68px] flex items-center justify-between">
        <button onClick={() => handleLinkClick('hero')} className="flex items-center text-left hover:opacity-95 transition-opacity">
          <Logo variant="full" />
        </button>
        <nav className="hidden lg:flex items-center gap-7">
          {navLinks.map((link) => {
            const isActive = activeSection === link.id;
            return (
              <button key={link.id} onClick={() => handleLinkClick(link.id)} className={`text-sm font-medium transition-colors whitespace-nowrap py-1 relative ${isActive ? 'text-[#E65100] font-semibold' : 'text-[#5C544B] hover:text-[#1E1B18]'}`}>
                {link.label}
                {isActive && <span className="absolute bottom-0 left-0 w-full h-0.5 bg-[#E65100] rounded-full" />}
              </button>
            );
          })}
        </nav>
        <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="lg:hidden p-2 rounded-lg text-[#5C544B] hover:bg-[#F0E6D8]" aria-label="Toggle navigation menu">
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#FCFAF7] border-b border-[#EADFCF] px-4 pt-2 pb-5 shadow-lg">
          <div className="flex flex-col gap-1">
            {navLinks.map((link) => (
              <button key={link.id} onClick={() => handleLinkClick(link.id)} className={`text-left px-3 py-2.5 rounded-lg text-sm font-medium ${activeSection === link.id ? 'bg-[#FBE8DE] text-[#BF360C] font-semibold' : 'text-[#5C544B]'}`}>
                {link.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};
