import React from 'react';
import { FoodItem, SiteConfig } from '../types';
import { extractYouTubeId } from '../data/initialData';
import { Compass, ArrowRight, MapPin } from 'lucide-react';

interface HeroProps {
  batchoyItem?: FoodItem;
  siteConfig?: SiteConfig;
  onExploreFood: () => void;
  onOpenMap: () => void;
}

export const Hero: React.FC<HeroProps> = ({ batchoyItem, siteConfig, onExploreFood, onOpenMap }) => {
  const batchoyPhoto = batchoyItem?.photo || '/images/foods/food-1.jpg';
  const batchoyTitle = batchoyItem?.title || 'La Paz Batchoy';
  const batchoyOrigin = batchoyItem?.originPlace || 'La Paz Public Market, Iloilo City';
  const greeting = siteConfig?.welcomeGreeting || 'Maayong adlaw! Welcome to Western Visayas';
  const title = siteConfig?.siteTitle || 'Namit 4 Visayas';
  const subtitle = siteConfig?.siteSubtitle || '"Maayong pag-abot sa amon banwa!" Step into Region VI—where the heart of Philippine hospitality meets legendary heirloom flavors across Panay Island, Guimaras, and Negros Occidental.';
  const videoId = extractYouTubeId(siteConfig?.youtubeVideoUrl || 'PB1_maFyzp8');
  const videoCaption = siteConfig?.videoCaption || 'Discover the sights, heritage streets, and cultural wonders of Western Visayas';

  return (
    <section id="hero" className="relative overflow-hidden pt-6 pb-16 md:pt-10 md:pb-20 border-b border-[#E8DDCF]">
      <div className="absolute top-0 right-0 -z-10 w-96 md:w-[600px] h-96 md:h-[600px] bg-gradient-to-bl from-[#FFB300]/15 via-[#E65100]/10 to-transparent rounded-full blur-3xl pointer-events-none" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gradient-to-r from-[#BF360C]/10 via-[#E65100]/15 to-[#0F4C3A]/10 border border-[#E65100]/25 text-[#BF360C] text-xs font-bold uppercase tracking-wider mb-3">
            <span className="w-2 h-2 rounded-full bg-[#E65100]" />
            <span>{greeting}</span>
          </div>
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-[#1E1B18] tracking-tight font-['Outfit']">
            {title.includes('4') ? <>{title.split('4')[0]}<span className="text-[#E65100]">4</span>{title.split('4').slice(1).join('4')}</> : title}
          </h1>
          <p className="text-base sm:text-lg text-[#5A5248] leading-relaxed mt-2 max-w-2xl">{subtitle}</p>
          <div className="flex flex-wrap items-center justify-center gap-3.5 pt-4">
            <button onClick={onExploreFood} className="px-6 py-3 text-sm font-bold text-white bg-[#E65100] hover:bg-[#BF360C] rounded-xl shadow-md transition-all flex items-center gap-2">
              <span>Explore Western Visayas Dishes</span><ArrowRight className="w-4 h-4" />
            </button>
            <button onClick={onOpenMap} className="px-5 py-3 text-sm font-semibold text-[#302B25] bg-white hover:bg-[#F5ECE1] border border-[#DCD3C7] rounded-xl shadow-xs flex items-center gap-2">
              <Compass className="w-4 h-4 text-[#0F4C3A]" /><span>Meet Group 4</span>
            </button>
          </div>
        </div>

        <div className="relative rounded-2xl overflow-hidden border border-[#E5DACD] bg-black shadow-xl">
          <div className="relative aspect-video max-h-[500px] w-full">
            <iframe className="w-full h-full" src={`https://www.youtube-nocookie.com/embed/${videoId}?rel=0&modestbranding=1&autoplay=0`} title="Western Visayas Tourism Video Header" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
          </div>
          <div className="px-5 py-3 bg-[#1C1917] text-white/80 flex flex-wrap items-center justify-between text-xs gap-2">
            <div><span className="font-bold text-amber-400">Featured Video:</span> <span>{videoCaption}</span></div>
            <span className="text-[11px] text-white/60">Region VI · Panay, Guimaras & Negros Occidental</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center pt-2">
          <div className="lg:col-span-6">
            <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-lg border border-[#E5DACD] overflow-hidden">
              <div className="aspect-[16/10] sm:aspect-[4/3] rounded-xl overflow-hidden relative bg-[#F0E6D8]">
                <img src={batchoyPhoto} alt={batchoyTitle} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent" />
                <div className="absolute top-3 left-3 bg-black/60 px-3 py-1 rounded-md text-xs font-semibold text-white">Featured Ilonggo Dish</div>
                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <div className="flex items-center gap-1.5 text-xs text-amber-300"><MapPin className="w-3.5 h-3.5" /><span>{batchoyOrigin}</span></div>
                  <h3 className="text-xl sm:text-2xl font-bold font-['Outfit'] mt-0.5">{batchoyTitle}</h3>
                </div>
              </div>
              <div className="mt-4 flex items-center gap-2.5 px-1 py-1">
                <img src={batchoyItem?.submitter.avatar || '/images/members/member-1.png'} alt={batchoyItem?.submitter.name || 'Group member'} className="w-9 h-9 rounded-full object-cover border-2 border-[#E65100]" />
                <div><div className="text-[10px] uppercase font-bold text-[#BF360C]">Submitted by</div><div className="text-xs font-bold">{batchoyItem?.submitter.name}</div></div>
              </div>
            </div>
          </div>
          <div className="lg:col-span-6">
            <div className="text-xs font-bold uppercase tracking-wider text-[#0F4C3A]">The culinary heart of Panay & Negros</div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1E1B18] font-['Outfit'] mt-2">A Feast of Traditions, Sea Breezes & Stories</h2>
            <p className="text-sm sm:text-base text-[#5C544B] leading-relaxed mt-4">Discover eight signature dishes and the student researchers behind them. Every entry combines food, place, heritage, and the personal work of Group 4.</p>
          </div>
        </div>
      </div>
    </section>
  );
};
