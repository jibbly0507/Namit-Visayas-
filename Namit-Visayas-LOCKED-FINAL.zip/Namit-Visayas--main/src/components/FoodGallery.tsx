import React, { useMemo, useState } from 'react';
import { FoodItem, Province } from '../types';
import { Search, Filter, Grid3X3, List, Eye } from 'lucide-react';

interface FoodGalleryProps {
  items: FoodItem[];
  introStory?: string;
  onSelectItem: (item: FoodItem) => void;
}

export const FoodGallery: React.FC<FoodGalleryProps> = ({ items, introStory, onSelectItem }) => {
  const [selectedProvince, setSelectedProvince] = useState<Province>('All');
  const [search, setSearch] = useState('');
  const [view, setView] = useState<'gallery' | 'list'>('gallery');
  const provinces: Province[] = ['All', 'Iloilo', 'Negros Occidental', 'Guimaras', 'Aklan'];

  const filtered = useMemo(() => items.filter((item) => {
    const provinceMatch = selectedProvince === 'All' || item.province === selectedProvince;
    const q = search.toLowerCase().trim();
    return provinceMatch && (!q || item.title.toLowerCase().includes(q) || item.province.toLowerCase().includes(q) || item.description.toLowerCase().includes(q));
  }), [items, selectedProvince, search]);

  return (
    <section id="gallery" className="py-14 sm:py-20 border-b border-[#E8DDCF] bg-[#FCFAF7]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="text-xs font-bold uppercase tracking-wider text-[#BF360C]">8 Regional Dishes</div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1E1B18] font-['Outfit'] mt-1">The Culinary Heart of Western Visayas</h2>
          <p className="text-sm sm:text-base text-[#685F53] mt-2">{introStory}</p>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-3 mb-7">
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            <Filter className="w-4 h-4 text-[#BF360C]" />
            {provinces.map((p) => <button key={p} onClick={() => setSelectedProvince(p)} className={`px-3 py-1.5 rounded-lg text-xs font-semibold border ${selectedProvince === p ? 'bg-[#BF360C] text-white border-[#BF360C]' : 'bg-white text-[#5C544B] border-[#DCD3C7]'}`}>{p}</button>)}
          </div>
          <div className="flex items-center gap-2 w-full md:w-auto">
            <div className="relative flex-1 md:w-64"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8A7F73]" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search dishes..." className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-[#DCD3C7] rounded-xl outline-none focus:border-[#E65100]" /></div>
            <button onClick={() => setView('gallery')} className={`p-2 rounded-lg border ${view === 'gallery' ? 'bg-[#FBE8DE] border-[#E65100] text-[#BF360C]' : 'bg-white border-[#DCD3C7]'}`} aria-label="Gallery view"><Grid3X3 className="w-4 h-4" /></button>
            <button onClick={() => setView('list')} className={`p-2 rounded-lg border ${view === 'list' ? 'bg-[#FBE8DE] border-[#E65100] text-[#BF360C]' : 'bg-white border-[#DCD3C7]'}`} aria-label="List view"><List className="w-4 h-4" /></button>
          </div>
        </div>

        {view === 'gallery' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filtered.map((item) => (
              <article key={item.id} className="bg-white rounded-2xl border border-[#E5DACD] overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col">
                <div className="relative aspect-[4/3] bg-[#EFE8DC]"><img src={item.photo} alt={item.title} className="w-full h-full object-cover" /><div className="absolute top-2.5 right-2.5 bg-black/60 px-2 py-0.5 rounded text-[11px] font-semibold text-white">{item.province}</div></div>
                <div className="p-4 flex-1 flex flex-col">
                  <div className="flex items-center gap-2.5 p-2 rounded-xl bg-[#FBF7F2] border border-[#EFE5D8]"><img src={item.submitter.avatar} alt={`${item.submitter.name} formal portrait`} className="w-9 h-9 rounded-full object-cover border-2 border-[#E65100]" /><div className="min-w-0"><div className="text-[10px] uppercase font-bold tracking-wider text-[#BF360C]">Submitted by</div><div className="text-xs font-bold truncate">{item.submitter.name}</div></div></div>
                  <h3 className="text-lg font-bold font-['Outfit'] mt-3">{item.title}</h3><div className="text-[10px] italic text-[#BF360C] mt-0.5">{item.nativeTitle}</div><p className="text-[11px] text-[#706659] mt-2 leading-relaxed line-clamp-4">{item.description}</p>
                  <button onClick={() => onSelectItem(item)} className="mt-auto pt-4"><span className="w-full py-2 rounded-lg bg-[#FBF7F2] border border-[#E8DDCF] text-xs font-semibold flex items-center justify-center gap-1.5"><Eye className="w-3.5 h-3.5 text-[#E65100]" />View Heritage Details</span></button>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="space-y-4">{filtered.map((item) => <article key={item.id} className="bg-white rounded-2xl border border-[#E5DACD] p-5 grid grid-cols-1 md:grid-cols-12 gap-5 items-center"><div className="md:col-span-4 aspect-[16/10] rounded-xl overflow-hidden"><img src={item.photo} alt={item.title} className="w-full h-full object-cover" /></div><div className="md:col-span-8"><div className="text-xs font-bold uppercase text-[#BF360C]">{item.province}</div><h3 className="text-2xl font-bold font-['Outfit']">{item.title}</h3><p className="text-sm text-[#706659] leading-relaxed mt-2">{item.description}</p><button onClick={() => onSelectItem(item)} className="mt-3 text-xs font-bold text-[#0F4C3A] hover:underline">View Heritage Details →</button></div></article>)}</div>
        )}
      </div>
    </section>
  );
};
