import React from 'react';
import { ArrowUp } from 'lucide-react';

interface FooterProps { onNavigate: (sectionId: string) => void; }

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => (
  <footer className="bg-[#1E1B18] text-[#DCD3C7] pt-14 pb-12 border-t border-[#36312B]">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12">
        <div className="md:col-span-6 space-y-4"><div className="flex items-center gap-3"><div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#E65100] to-[#FFB300] flex items-center justify-center text-white font-extrabold text-lg">4</div><span className="font-extrabold text-xl text-white font-['Outfit']">Namit 4 Visayas</span></div><p className="text-xs text-[#A89C8F] leading-relaxed max-w-sm">A Food Tourism Destination Platform developed for the Tourism and Promotion Services Practical Examination by Group 4.</p></div>
        <div className="md:col-span-6"><div className="text-xs font-bold uppercase tracking-wider text-white mb-3">Navigation</div><div className="flex flex-wrap gap-4 text-xs"><button onClick={() => onNavigate('hero')}>Showcase & Video</button><button onClick={() => onNavigate('gallery')}>8 Regional Dishes</button><button onClick={() => onNavigate('about')}>Group 4 Member Directory</button></div></div>
      </div>
      <div className="pt-8 border-t border-[#36312B] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#8C7D6D]"><div>© 2026 <strong>Namit 4 Visayas</strong> · Western Visayas Food Tourism Showcase · Group 4</div><button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="flex items-center gap-1.5 hover:text-white"><span>Back to top</span><ArrowUp className="w-3.5 h-3.5" /></button></div>
    </div>
  </footer>
);
