import { FoodItem, LocalDiner, TravelSpot, ReferenceItem, SiteConfig } from '../types';

export const INITIAL_FOOD_ITEMS: FoodItem[] = [
  {
    id: 'food-1', title: 'La Paz Batchoy', nativeTitle: 'Espesyal nga La Paz Batchoy', province: 'Iloilo',
    originPlace: 'La Paz Public Market, Iloilo City',
    description: 'La Paz Batchoy is arguably the most famous iconic dish from Western Visayas, originating specifically from the La Paz district in Iloilo City. A noodle soup made of pork, beef, or chicken meat, crushed pork cracklings (called chicharon), round egg noodles (called miki), and pork offal (liver, intestines, and marrow) served in a hot, savory broth cooked with pork stock and shrimp paste.',
    culturalBackground: 'The dish is celebrated for its deep, umami-rich broth and is typically topped with toasted garlic and chopped green onions. It is traditionally eaten hot alongside a fresh steamed rice cake (puto). The supplied source states that it originated in the La Paz Public Market in Iloilo City during the late 1930s to 1940s, with popularization credited to local stall owners Federico "Deco" Guillergan Sr. and Teodorico "Ted" Lepura.',
    photo: '/images/foods/food-1.jpg',
    submitter: { id: 'member-1', name: 'Santos, Matildah Jillian G.', role: 'Group Leader', avatar: '/images/members/member-1.png', studentNumber: 'St. Elizabeth Of Hungary' },
    flavorProfile: ['Umami-rich broth', 'Toasted garlic', 'Savory pork stock'],
    keyIngredients: ['Pork, beef, or chicken', 'Chicharon', 'Miki egg noodles', 'Pork offal', 'Pork stock', 'Shrimp paste'],
    bestPairing: 'Fresh steamed rice cake (puto)', rating: 0, reviewCount: 0,
    funFact: 'Source: Travel & Food Heritage Documentation (Tita S Travels / Zoy To The World Food Archive).'
  },
  {
    id: 'food-2', title: 'Chicken Inasal', nativeTitle: 'Manok nga Inasal sa Bacolod', province: 'Negros Occidental',
    originPlace: 'Manokan Country, Bacolod City',
    description: 'Chicken Inasal is a popular Filipino grilled chicken dish that originated in Bacolod City. The chicken is marinated in a mixture of vinegar, calamansi, garlic, ginger, lemongrass, and annatto oil, giving it a savory, tangy, and slightly smoky flavor. It is grilled over hot charcoal while being basted with oil and seasonings to keep it juicy and flavorful.',
    culturalBackground: 'The supplied source describes Chicken Inasal as originating in Bacolod City during the 1970s. The word "inasal" comes from the Hiligaynon and Visayan term asal, meaning to grill or roast over charcoal.',
    photo: '/images/foods/food-2.jpg',
    submitter: { id: 'member-2', name: 'Bation, Kris Pauline E.', role: 'Group Member', avatar: '/images/members/member-2.jpg', studentNumber: 'St. Elizabeth Of Hungary' },
    flavorProfile: ['Savory', 'Tangy', 'Slightly smoky'],
    keyIngredients: ['Vinegar', 'Calamansi', 'Garlic', 'Ginger', 'Lemongrass', 'Annatto oil'],
    bestPairing: 'Rice and dipping sauces such as vinegar with chili and soy sauce', rating: 0, reviewCount: 0,
    funFact: 'Source information supplied by the member document; origin/context states Bacolod City in the 1970s.'
  },
  {
    id: 'food-3', title: 'Baye-Baye', nativeTitle: 'Babaye Sang Iloilo', province: 'Iloilo',
    originPlace: 'Molo Heritage District, Iloilo City',
    description: 'Baye-Baye is a traditional Filipino sweet treat (kakanin) native to Western Visayas, widely cherished for its distinct smoky aroma, rich coconut flavor, and soft, chewable texture. It is made from toasted immature glutinous rice (pinipig) or toasted corn flour, mixed with finely shredded young coconut meat (buko), coconut water, and brown sugar or muscovado.',
    culturalBackground: 'The supplied source describes Baye-Baye as a portable hand-held snack shaped into small cylinders or compact rectangular bars and typically wrapped in wilted banana leaves or clear plastic.',
    photo: '/images/foods/food-3.jpg',
    submitter: { id: 'member-3', name: 'Manansala, Ma. Sophia B.', role: 'Group Member', avatar: '/images/members/member-3.jpg', studentNumber: 'St. Elizabeth Of Hungary' },
    flavorProfile: ['Smoky aroma', 'Rich coconut flavor', 'Balanced sweetness'],
    keyIngredients: ['Toasted pinipig or toasted corn flour', 'Young coconut meat', 'Coconut water', 'Brown sugar or muscovado'],
    bestPairing: 'Hand-held snack traditionally wrapped in banana leaves or clear plastic', rating: 0, reviewCount: 0,
    funFact: 'Source: Wikipedia entry for Baye-Baye, as supplied in the member document.'
  },
  {
    id: 'food-4', title: 'Binakol', nativeTitle: 'Binakoe, Darag Kinaray-a', province: 'Aklan',
    originPlace: 'Central Iloilo & Antique Highlands',
    description: 'Binakol is a Filipino soup that the supplied document associates with Aklan. It is traditionally cooked in a fresh node of bamboo or halved coconut shells and uses fresh coconut water for its flavorful broth.',
    culturalBackground: 'The dressed native chicken is pounded or beaten to make the meat tender, cut into serving pieces, and cooked low and slow in coconut water with onions, ginger, and lemongrass. Leaves or fruits are added for sourness, with papaya or chayote and leafy vegetables such as chili leaves or spinach completing the dish.',
    photo: '/images/foods/food-4.jpg',
    submitter: { id: 'member-4', name: 'Bautista, Tanya Mae A.', role: 'Group Member', avatar: '/images/members/member-4.jpg', studentNumber: 'St. Elizabeth Of Hungary' },
    flavorProfile: ['Coconut-water broth', 'Aromatic ginger', 'Lemongrass'],
    keyIngredients: ['Native chicken', 'Fresh coconut water', 'Onions', 'Ginger', 'Lemongrass', 'Papaya or chayote', 'Leafy vegetables'],
    bestPairing: 'Not specified in the supplied document', rating: 0, reviewCount: 0,
    funFact: 'Source: Kawaling Pinoy chicken binakol reference supplied in the member document.'
  },
  {
    id: 'food-5', title: 'Biscocho', nativeTitle: 'Kinihad ng Iloilo', province: 'Guimaras',
    originPlace: 'Jordan & Buenavista, Guimaras Island',
    description: 'Biscocho is a popular Filipino toasted bread that is especially associated with Iloilo in Western Visayas. It is made by baking or toasting bread until crispy, then coating it with butter and sugar.',
    culturalBackground: 'It is known for its crunchy texture and sweet, buttery flavor and is commonly eaten as a snack or paired with coffee or hot chocolate.',
    photo: '/images/foods/food-5.jpg',
    submitter: { id: 'member-5', name: 'Torres, Rihanna C.', role: 'Group Member', avatar: '/images/members/member-5.png', studentNumber: 'St. Elizabeth Of Hungary' },
    flavorProfile: ['Crunchy', 'Sweet', 'Buttery'],
    keyIngredients: ['Bread', 'Butter', 'Sugar'],
    bestPairing: 'Coffee or hot chocolate', rating: 0, reviewCount: 0,
    funFact: 'The supplied source associates Biscocho especially with Iloilo in Western Visayas.'
  },
  {
    id: 'food-6', title: 'Kansi', nativeTitle: 'Kamansi ng Iloilo', province: 'Negros Occidental',
    originPlace: 'Silay Heritage City & Bacolod City',
    description: 'Kansi is a traditional Western Visayan beef soup strongly associated with Bacolod City and Negros Occidental, although it is also part of the wider Ilonggo culinary tradition. It is often compared to a combination of bulalo and sinigang because of its beef-and-bone broth and distinctive sour flavor.',
    culturalBackground: 'A sour beef soup made primarily with beef shank and bone marrow, slowly simmered until tender and gelatinous, then flavored with batwan, a native souring fruit, along with lemongrass, tomatoes, garlic, chili, and annatto (atsuete). Green jackfruit may also be added. The supplied source notes that sources differ somewhat on its precise origin.',
    photo: '/images/foods/food-6.jpg',
    submitter: { id: 'member-6', name: 'Razon, Rushney Vane S.', role: 'Group Member', avatar: '/images/members/member-6.jpg', studentNumber: 'St. Elizabeth Of Hungary' },
    flavorProfile: ['Sour', 'Beefy', 'Rich bone broth'],
    keyIngredients: ['Beef shank', 'Bone marrow', 'Batwan', 'Lemongrass', 'Tomatoes', 'Garlic', 'Chili', 'Annatto', 'Green jackfruit (optional)'],
    bestPairing: 'Not specified in the supplied document', rating: 0, reviewCount: 0,
    funFact: 'Sources supplied: GMA News Online; Negros Season of Culture; Bacolod food documentation and recipe references.'
  },
  {
    id: 'food-7', title: 'Pancit Molo', nativeTitle: 'Sopa de Molo of Iloilo', province: 'Iloilo',
    originPlace: 'Baybay Beach, Roxas City (Seafood Capital)',
    description: 'Pancit Molo is a traditional Filipino wonton soup featuring pork and shrimp dumplings in a rich chicken broth, originating from the Molo district of Iloilo City. Unlike other traditional Filipino pancit dishes, it is not a stir-fried noodle meal but rather a comforting broth.',
    culturalBackground: 'The dish consists of meat-filled dumplings, shredded chicken, and shrimp submerged in a savory, garlic-infused broth. The piping-hot soup is often garnished with green onions and fried garlic bits.',
    photo: '/images/foods/food-7.jpg',
    submitter: { id: 'member-7', name: 'Aviles, Ayesa Nicole F.', role: 'Group Member', avatar: '/images/members/member-7.png', studentNumber: 'St. Elizabeth Of Hungary' },
    flavorProfile: ['Savory broth', 'Garlic-infused', 'Comforting'],
    keyIngredients: ['Ground pork & minced shrimp', 'Wonton wrappers', 'Shredded chicken', 'Shrimp', 'Green onions', 'Fried garlic'],
    bestPairing: 'Served piping hot and garnished with green onions and fried garlic bits', rating: 0, reviewCount: 0,
    funFact: 'Source supplied: Wikipedia Pancit Molo reference in the member document.'
  },
  {
    id: 'food-8', title: 'Laswa', nativeTitle: 'Binakol nga Manok sa Butong', province: 'Aklan',
    originPlace: 'Kalibo & Numancia, Aklan',
    description: 'Rooted in the backyard gardens of Western Visayas, Laswa is described in the supplied source as a vibrant, clear-broth vegetable soup that celebrates homegrown produce.',
    culturalBackground: 'The supplied source describes a fresh medley of squash, okra, eggplant, and silk squash simmered with sweet local shrimp and tomatoes, with jute leaves (saluyot) giving the dish its signature silky texture. It is lightly seasoned so the ingredients can shine.',
    photo: '/images/foods/food-8.jpg',
    submitter: { id: 'member-8', name: 'Matitu, Franz Jairus', role: 'Group Member', avatar: '/images/members/member-8.png', studentNumber: 'St. Elizabeth Of Hungary' },
    flavorProfile: ['Light', 'Fresh vegetable flavors', 'Clear broth'],
    keyIngredients: ['Squash', 'Okra', 'Eggplant', 'Silk squash', 'Local shrimp', 'Tomatoes', 'Jute leaves (saluyot)'],
    bestPairing: 'Not specified in the supplied document', rating: 0, reviewCount: 0,
    funFact: 'The supplied source describes Laswa as an Ilonggo comfort food rooted in backyard gardens of Western Visayas.'
  },
];

export const INITIAL_DINERS: LocalDiner[] = [];
export const TRAVEL_SPOTS: TravelSpot[] = [];
export const REFERENCES_DATA: ReferenceItem[] = [];

export const DEFAULT_SITE_CONFIG: SiteConfig = {
  welcomeGreeting: 'Maayong adlaw! Welcome to Western Visayas',
  siteTitle: 'Namit 4 Visayas',
  siteSubtitle: '"Maayong pag-abot sa amon banwa!" Step into Region VI—where the heart of Philippine hospitality meets legendary heirloom flavors across Panay Island, Guimaras, and Negros Occidental.',
  youtubeVideoUrl: 'PB1_maFyzp8',
  videoCaption: 'Discover the sights, heritage streets, and cultural wonders of Western Visayas',
  galleryIntroStory: 'Explore eight signature delicacies curated by Group 4, with each dish representing a food tradition documented by its assigned student researcher.',
  manifestoTitle: 'Group 4 · Tourism & Promotion Team',
  manifestoText: 'Eight student researchers collaborated on Namit 4 Visayas, documenting and curating one signature delicacy each to represent the cultural soul of Western Visayas.'
};

export function extractYouTubeId(urlOrId: string): string {
  if (!urlOrId) return '';
  const trimmed = urlOrId.trim();
  const match = trimmed.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);
  return match ? match[1] : trimmed;
}
