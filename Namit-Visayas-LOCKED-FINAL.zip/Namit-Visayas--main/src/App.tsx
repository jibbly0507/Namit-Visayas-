import React, { useMemo, useState } from 'react';
import { FoodItem } from './types';
import { INITIAL_FOOD_ITEMS, DEFAULT_SITE_CONFIG } from './data/initialData';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { FoodGallery } from './components/FoodGallery';
import { FoodDetailModal } from './components/FoodDetailModal';
import { AboutUs } from './components/AboutUs';
import { Footer } from './components/Footer';

export default function App() {
  const [activeSection, setActiveSection] = useState('hero');
  const [detailModalItem, setDetailModalItem] = useState<FoodItem | null>(null);

  const foodItems = INITIAL_FOOD_ITEMS;
  const siteConfig = DEFAULT_SITE_CONFIG;
  const batchoyItem = useMemo(() => foodItems.find((item) => item.id === 'food-1')!, [foodItems]);

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    if (sectionId === 'hero') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="min-h-screen bg-[#FCFAF7] text-[#24211D] flex flex-col font-sans">
      <Navbar activeSection={activeSection} onNavigate={handleNavigate} />

      <main className="flex-1">
        <Hero
          batchoyItem={batchoyItem}
          siteConfig={siteConfig}
          onExploreFood={() => handleNavigate('gallery')}
          onOpenMap={() => handleNavigate('about')}
        />

        <FoodGallery
          items={foodItems}
          introStory={siteConfig.galleryIntroStory}
          onSelectItem={(item) => setDetailModalItem(item)}
        />

        <AboutUs
          items={foodItems}
          manifestoTitle={siteConfig.manifestoTitle}
          manifestoText={siteConfig.manifestoText}
          onSelectFood={(item) => {
            handleNavigate('gallery');
            setDetailModalItem(item);
          }}
        />
      </main>

      <Footer onNavigate={handleNavigate} />

      <FoodDetailModal
        item={detailModalItem}
        onClose={() => setDetailModalItem(null)}
      />
    </div>
  );
}
