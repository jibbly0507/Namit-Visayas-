# Namit 4 Visayas — Locked Content Build

This build fixes the cross-user content problem caused by browser-local `localStorage` / IndexedDB customization.

## What changed
- The public site no longer reads food/member/site content from `localStorage` or IndexedDB.
- The public Master Website Content Customizer is removed.
- Member photo/name edit controls are removed.
- Food photo/info edit controls are removed.
- The 8 member portraits from `Members.pdf` are bundled under `public/images/members/`.
- The 8 food photos from `Tourism Western Visayas.pdf` are bundled under `public/images/foods/`.
- The 8 food records and member assignments are hard-coded in `src/data/initialData.ts`.

## Important
The supplied source ZIP did not contain the previously customized diner-map, travel-spot, or reference datasets; the locked build therefore does not invent replacement records for those sections. The supplied member/food PDFs are used as the source of truth for the content included here.

To change the locked content later, edit `src/data/initialData.ts` and redeploy the site.
